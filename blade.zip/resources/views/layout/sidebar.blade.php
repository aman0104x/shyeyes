<!-- Dating Sidebar -->
<div class="dating-sidebar-container">
	<div class="dating-sidebar-logo">
		<img src="{{ asset("images/shylogo1.png") }}" alt="Logo">
	</div>
	<ul class="dating-sidebar-menu">
		<li><a href="{{ route("admin.dashboard") }}" class="active"><i class="fas fa-home"></i> Dashboard</a></li>
		<li><a href="{{ route("admin.users.index") }}"><i class="fas fa-users"></i> User Management</a></li>
		<li><a href="{{ route("admin.agents.index") }}"><i class="fas fa-user-tie"></i> Agent Management</a></li>
		<li><a href=#><i class="fas fa-comments"></i> Chats Monitoring</a></li>
		<li><a href="{{ route("reports.index") }}"><i class="fas fa-chart-line"></i> Reports</a></li>
		<li><a href=#><i class="fas fa-credit-card"></i> Payments</a></li>
		<li><a href="{{ route("admin.membership-plans.index") }}"><i class="fas fa-crown"></i> Membership Plans</a></li>
		{{-- development --}}
		<li>
			<a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
				<i class="fas fa-sign-out-alt"></i> Logout
			</a>
			<form id="logout-form" action="{{ route("admin.logout") }}" method="POST" style="display: none;">
				@csrf
			</form>
		</li>
	</ul>
</div>

<script>
	document.addEventListener('DOMContentLoaded', function() {
		const sidebar = document.querySelector('.dating-sidebar-container');
		const sidebarToggle = document.querySelector('#sidebarToggle');

		// Function to toggle sidebar
		function toggleSidebar() {
			sidebar.classList.toggle('sidebar-open');
			updateToggleButton();
		}

		// Toggle sidebar on button click
		if (sidebarToggle) {
			sidebarToggle.addEventListener('click', function() {
				toggleSidebar();
			});
		}

		// Close sidebar when clicking on a link (for mobile)
		const sidebarLinks = document.querySelectorAll('.dating-sidebar-menu a');
		sidebarLinks.forEach(link => {
			link.addEventListener('click', function() {
				if (window.innerWidth < 992) {
					sidebar.classList.remove('sidebar-open');
					updateToggleButton();
				}
			});
		});

		// Handle window resize
		window.addEventListener('resize', function() {
			if (window.innerWidth >= 992) {
				sidebar.classList.remove('sidebar-open');
				updateToggleButton();
			}
		});

		// Update toggle button icon
		function updateToggleButton() {
			const isOpen = sidebar.classList.contains('sidebar-open');
			if (sidebarToggle) {
				sidebarToggle.innerHTML = isOpen ?
					'<i class="fas fa-times"></i>' :
					'<i class="fas fa-bars"></i>';
			}
		}
	});
</script>
